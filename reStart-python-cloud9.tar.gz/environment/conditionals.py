#userReply = input("Do you need to ship a package? (enter yes or no) " )
#if userReply == "yes":
#    print("We can help to ship that package!")
#else:
#    print("Please comback when you ready to ship this package.")
    
    
userReply = input("Would you like to buy stamps, buy an envelope, or make a copy? (Enter stamps, envelope, or copy) ")
if userReply == "stamps":
    print("we have many stamp designs to choose from.")
elif userReply == "envelope":
    print("We have many envelope size to chooze from.")
elif userReply == "copy":
    copies = input("How many copies would you like? (Enter a number) ")
    print("Here are {} copies.".format(copies))
else:
    print("Thank you. Please come again.")
        
    
    