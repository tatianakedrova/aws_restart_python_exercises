import csv
import copy

#efine a dictionary that will serve as your composite type for reading the tabular data
myVehicle = {
    "vin" : "<empty>", #<>Placeholder for missing data; null, ""
    "make" : "<empty>" ,
    "model" : "<empty>" ,
    "year" : 0,
    "range" : 0,
    "topSpeed" : 0,
    "zeroSixty" : 0.0,
    "mileage" : 0
}

# Use a for loop to iterate over the initial keys and values of the dictionary
for key, value in myVehicle.items():
    print("{} : {}".format(key,value))
    
# Define an empty list to hold the car inventory that you will read
myInventoryList = []


#Copying the CSV file into memory
with open('car_fleet.csv') as csvFile:  # Opens the file
    csvReader = csv.reader(csvFile, delimiter=',')  # Reads the file as CSV with ',' as delimiter
    lineCount = 0  # Initializes a counter for lines
    for row in csvReader:  # Loops through each row in the CSV file
        if lineCount == 0:  # If it's the first row (header row)
            print(f'Column names are: {", ".join(row)}')  # Print the column headers
            lineCount += 1  #Increments lineCount to move to the data rows.
        else:
            print(f'vin: {row[0]} make: {row[1]} model: {row[2]} year: {row[3]} range: {row[4]} topSpeed: {row[5]} zeroSixty: {row[6]} miLeage: {row[7]}')
            currentVehicle = copy.deepcopy(myVehicle)   #Creates a deep copy of the template to avoid overwriting the original or previously added data.
            currentVehicle["vin"] = row[0]  
            currentVehicle["make"] = row[1]  
            currentVehicle["model"] = row[2]  
            currentVehicle["year"] = row[3]  
            currentVehicle["range"] = row[4]  
            currentVehicle["topSpeed"] = row[5]  
            currentVehicle["zeroSixty"] = row[6]  
            currentVehicle["mileage"] = row[7] 
            myInventoryList.append(currentVehicle) #append each record to the inventory list.
            lineCount +=1
    
    print(f'Processed {lineCount} lines.')


for myCarProperties in myInventoryList:
    for key, value in myCarProperties.items():
        print("{} : {}".format(key,value))
        print("-----")
    