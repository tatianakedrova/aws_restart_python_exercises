myFruitList = ["apple", "banana", "cherry"]
print(myFruitList)
print(type(myFruitList))

print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])

myFruitList[2] ="orange"
print(myFruitList)


#tupple

myFinalAnswerTupple = ("apple","banana", "pinnaple")
print(myFinalAnswerTupple)
print(type(myFinalAnswerTupple))

print(myFinalAnswerTupple[0])
print(myFinalAnswerTupple[1])
print(myFinalAnswerTupple[2])

#dicctionary

myFavoritFruitDicctionary = {
    "Akura" : "apple",
    "Saanvi" : "banana",
    "Paulo" : "pinapple"
}
print(myFavoritFruitDicctionary)
print(myFavoritFruitDicctionary["Akura"])
print(myFavoritFruitDicctionary["Saanvi"])
print(myFavoritFruitDicctionary["Paulo"])