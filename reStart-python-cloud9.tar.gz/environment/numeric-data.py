print("Python has 3 numerical type: int, float and complex.")

#numeric type
myValue = 1
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))

myValue = 3.14
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))

myValue = 5j
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))


#boolean type
myValue = True
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the type " + str(type(myValue)))